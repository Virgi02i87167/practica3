﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practica3.forms
{
    public partial class imagen : Form
    {
        public imagen()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //utilizar la clase openfiledialog para visualizar la ventana
            OpenFileDialog abrir = new OpenFileDialog();
            //Filtro para abrir imagens jpg
            abrir.Filter = "JPGE (*.JPG)|*.JPG|BMP(*.BMP)| *.BMP";

            //validar ventana y mostrarla
            //showDialo abre una ventana, el if valida nuestras respuestas
            //en la ventana
            if (abrir.ShowDialog() == DialogResult.OK)
            {
                //validaciones sobre la imagen
                pictureBox1.Image = Image.FromFile(abrir.FileName);
            }
        }
    }
}
