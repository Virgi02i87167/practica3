using System.ComponentModel;
using System.Windows.Forms;

namespace ejercicio2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private bool IsImg = true;
        private void button1_Click(object sender, EventArgs e)
        {
            if (IsImg)
            {
                pictureBox1.Image = Image.FromFile("C:\\Users\\alfar\\Downloads\\sads.jpg");
                IsImg = false;
            }
            else
            {
                pictureBox1.Image = Image.FromFile("C:\\Users\\alfar\\Downloads\\R.jpg");
                IsImg = true;
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (IsImg == true)
            {
                pictureBox1.Image = Image.FromFile("C:\\Users\\alfar\\Downloads\\sads.jpg");
                IsImg = false;
            }
            else
            {
                pictureBox1.Image = Image.FromFile("C:\\Users\\alfar\\Downloads\\R.jpg");
                IsImg = true;
            }
        }
    }
}